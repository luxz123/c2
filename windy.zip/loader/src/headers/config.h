#pragma once

#define HTTP_SERVER "154.53.37.227"
#define HTTP_PORT 80

#define TFTP_SERVER "154.53.37.227"
