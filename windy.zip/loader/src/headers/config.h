#pragma once

#define HTTP_SERVER "154.53.50.130"
#define HTTP_PORT 80

#define TFTP_SERVER "154.53.50.130"
