#pragma once

#define HTTP_SERVER "5.189.160.245"
#define HTTP_PORT 80

#define TFTP_SERVER "5.189.160.245"
